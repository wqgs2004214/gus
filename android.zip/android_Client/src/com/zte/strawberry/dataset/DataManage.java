package com.zte.strawberry.dataset;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.zte.strawberry.entity.StbyContact;
import com.zte.strawberry.entity.StbyMessage;


/**
 * @author 6235000036
 */
public class DataManage {
	
	/**
	 * 获取消息列表
	 * 
	 * @author 6235000036
	 * 
	 */
	public static ArrayList<HashMap<String, Object>> getMessageData(){
		ArrayList<HashMap<String, Object>> lstMessageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小李: Hi~~!");
		map.put("MassageTime", "09:08 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "少林: 好啊~~");
		map.put("MassageTime", "09:09 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小李: 今天下午有会议要记得参加啊，别忘记了");
		map.put("MassageTime", "09:10 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "少林: 我知道了，对了你记得带上笔记本，我今天没带");
		map.put("MassageTime", "09:11 8.Oct");
		lstMessageItem.add(map);
		
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小李: 今天下午有会议要记得参加啊，别忘记了今天下午有会议要记得参加啊，别忘记了别忘记了今天下午");
		map.put("MassageTime", "09:12 8.Oct");
		lstMessageItem.add(map);

    	
        return lstMessageItem;
	}
	
	/**
	 * 获取消息列表2
	 * 
	 * @author 6235000036
	 * 
	 */
	public static ArrayList<HashMap<String, Object>> getMessageData1(){
		ArrayList<HashMap<String, Object>> lstMessageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小丽: Hi~~!");
		map.put("MassageTime", "09:08 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "少林: 好啊~~");
		map.put("MassageTime", "09:09 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小丽: 你有昨天项目会议资料吗？");
		map.put("MassageTime", "09:10 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "少林: 那可是内部机密文件，不能随意外传！(*^__^*) ");
		map.put("MassageTime", "09:11 8.Oct");
		lstMessageItem.add(map);
		
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小丽: 你不给，我找别人要就是了。哼");
		map.put("MassageTime", "09:12 8.Oct");
		lstMessageItem.add(map);

    	
        return lstMessageItem;
	}
	
	/**
	 * 获取消息列表2
	 * 
	 * @author 6235000036
	 * 
	 */
	public static ArrayList<HashMap<String, Object>> getMessageData2(){
		ArrayList<HashMap<String, Object>> lstMessageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小张: Hi，忙不？");
		map.put("MassageTime", "09:08 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "少林: 今天事是有点多");
		map.put("MassageTime", "09:11 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "小张: 那明天再和你讨论那个新项目。");
		map.put("MassageTime", "09:11 8.Oct");
		lstMessageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ChatMassage", "少林: 好的，明天时间多。");
		map.put("MassageTime", "09:12 8.Oct");
		lstMessageItem.add(map);
    	
        return lstMessageItem;
	}
	
	/**
	 * 获取联系人
	 * 
	 * @author 6235000036
	 * 
	 */
	public static ArrayList<HashMap<String, Object>> getContacts(){
		ArrayList<HashMap<String, Object>> lstContact = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("Name", "小李");
		lstContact.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("Name", "小丽");
		lstContact.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("Name", "小张");
		lstContact.add(map);
    	
        return lstContact;
	}
	
	/**
	 * @param con
	 * @return 某個联系人對應的聊天记录
	 */
	public static ArrayList<HashMap<String, Object>> getMessageData(StbyContact con) {
		ArrayList<HashMap<String, Object>> result = new ArrayList<HashMap<String, Object>>();
		List<StbyMessage> messages = con.getMessages();
		for (StbyMessage conMessage : messages) {
			HashMap<String, Object> item = new HashMap<String, Object>();
			item.put("ChatMassage", conMessage.getMessageTime());
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
			item.put("MassageTime", sdf.format(conMessage.getMessageTime()));
			result.add(item);
		}
		return result;
	}

	
}
