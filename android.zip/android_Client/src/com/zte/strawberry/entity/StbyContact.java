package com.zte.strawberry.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author 6235000036
 * @version Create：2010-12-8 下午04:37:52
 */

//import android.provider.Contacts
//import android.provider.ContactsContract.Contacts;


@SuppressWarnings("rawtypes")
public class StbyContact  implements Comparable, Cloneable {
	
	private String id;
	private String name;
	private String email;
	private String phoneNumber;
	private String officeNumber;
	private String homeNumber;
	private String nickName;
	private Date birthday;//private SimpleDateFormat birthday;
	private String location;
	private String selfIntro;
	private List<StbyMessage> messages = new ArrayList<StbyMessage>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getOfficeNumber() {
		return officeNumber;
	}

	public void setOfficeNumber(String officeNumber) {
		this.officeNumber = officeNumber;
	}

	public String getHomeNumber() {
		return homeNumber;
	}

	public void setHomeNumber(String homeNumber) {
		this.homeNumber = homeNumber;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSelfIntro() {
		return selfIntro;
	}

	public void setSelfIntro(String selfIntro) {
		this.selfIntro = selfIntro;
	}

	public int compareTo(Object another) {
		StbyContact anoth = null;
		if (!(another instanceof StbyContact))
			return 0;
		else
			anoth = (StbyContact) another;
		return this.name.compareTo(anoth.name);
	}
	
	public List<StbyMessage> getMessages() {
		return messages;
	}

	public void setComments(List<StbyMessage> messages) {
		this.messages = messages;
	}
	

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\n id:" + this.getId());
		sb.append("\n name:" + this.getName());
		sb.append("\n email:" + this.getEmail());
		sb.append("\n phoneNumber:" + this.getPhoneNumber());
		sb.append("\n officeNumber:" + this.getOfficeNumber());
		sb.append("\n homeNumber:" + this.getHomeNumber());
		sb.append("\n nickName:" + this.getNickName());
		sb.append("\n birthday:" + this.getBirthday());
		sb.append("\n location:" + this.getLocation());
		sb.append("\n selfIntro:" + this.getSelfIntro());
		return sb.toString();
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	
}
