package com.zte.strawberry.entity;

import java.util.Calendar;

/**
 * @author 6235000036
 * @version Create：2010-12-9 上午10:25:55
 */

public class StbyMessage {
	
	private Long id;
	private String talker;
	private String message;
	private Long frendId;
	private Calendar messageTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTalker() {
		return talker;
	}

	public void setTalker(String talker) {
		this.talker = talker;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getFrendId() {
		return frendId;
	}

	public void setFrendId(Long frendId) {
		this.frendId = frendId;
	}

	public Calendar getMessageTime() {
		return messageTime;
	}

	public void setMessageTime(Calendar messageTime) {
		this.messageTime = messageTime;
	}
	
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\n talker:" + this.getTalker());
		sb.append("\n message:" + this.getMessage());
		sb.append("\n frendId:" + this.getFrendId());
		sb.append("\n messageTime:" + this.getMessageTime());
		sb.append("\n id:" + this.getId());
		return sb.toString();
	}
	
}
