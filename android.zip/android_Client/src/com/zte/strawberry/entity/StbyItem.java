package com.zte.strawberry.entity;


public class StbyItem {
	
	private String name;
//	private ImageView itemImage;
	
	public StbyItem(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
