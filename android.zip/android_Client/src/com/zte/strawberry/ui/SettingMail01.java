package com.zte.strawberry.ui;


import android.os.Bundle;
import android.preference.PreferenceActivity;

public class SettingMail01 extends PreferenceActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		addPreferencesFromResource(R.xml.set_mail);				
	}	
}
