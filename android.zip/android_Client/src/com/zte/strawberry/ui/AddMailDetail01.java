package com.zte.strawberry.ui;


import android.os.Bundle;
import android.preference.PreferenceActivity;

public class AddMailDetail01 extends PreferenceActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		addPreferencesFromResource(R.xml.add_mail);
		
//		EditTextPreference
//		this.setb
		
	}

//	// 按下任意键跳转到登陆界面
//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		Intent intent = new Intent(AddMailDetail01.this, Strawberry.class);
//		startActivity(intent);
//		return super.onKeyDown(keyCode, event);
//	}
	

}
