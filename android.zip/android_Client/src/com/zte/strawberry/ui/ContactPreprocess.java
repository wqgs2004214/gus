package com.zte.strawberry.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.zte.strawberry.ui.tool.DialogTool;

public class ContactPreprocess extends Activity {



	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contact_preprocess);
		
		Button btnLink = (Button)findViewById(R.id.btn_contpreprocess_link);
		Button btnHome = (Button)findViewById(R.id.btn_contpreprocess_home);
		Button btnMore = (Button)findViewById(R.id.btn_contpreprocess_more);

		View viewPrecontactChat = (View)findViewById(R.id.rl_precontact_chat);
		View viewPrecontactWritemail = (View)findViewById(R.id.rl_precontact_writemail);
		View viewPrecontactCallmobile = (View)findViewById(R.id.rl_precontact_callmobile);
		View viewPrecontactSendsms = (View)findViewById(R.id.rl_precontact_sendsms);
		View viewPrecontactCalloffice = (View)findViewById(R.id.rl_precontact_calloffice);
		View viewPrecontactCallhome = (View)findViewById(R.id.rl_precontact_callhome);
		View viewPrecontactEdit = (View)findViewById(R.id.rl_precontact_edit);
		
		viewPrecontactChat.setOnClickListener(viewListener);
		viewPrecontactWritemail.setOnClickListener(viewListener);
		viewPrecontactCallmobile.setOnClickListener(viewListener);
		viewPrecontactSendsms.setOnClickListener(viewListener);
		viewPrecontactCalloffice.setOnClickListener(viewListener);
		viewPrecontactCallhome.setOnClickListener(viewListener);
		viewPrecontactEdit.setOnClickListener(viewListener);
		
		btnLink.setOnClickListener(buttonListener);
		btnHome.setOnClickListener(buttonListener);
		btnMore.setOnClickListener(buttonListener);
	}
	
	
	private OnClickListener buttonListener = new OnClickListener()
	{
		public void onClick(View v)
		{  
//			v.setBackgroundColor(Color.GREEN);
			int btnId = v.getId();
			if (btnId == R.id.btn_contpreprocess_link){
				Intent intent = new Intent(ContactPreprocess.this, ContactPrefile.class);
				startActivity(intent);
			}else if(btnId == R.id.btn_contpreprocess_home){
//				DialogTool.showInfo(ContactPreprocess.this, "Home");	
				Intent intent = new Intent(ContactPreprocess.this, Strawberry.class);
				startActivity(intent);
			}else if(btnId == R.id.btn_contpreprocess_more){
				DialogTool.showInfo(ContactPreprocess.this, "More");
			}else{
				DialogTool.showInfo(ContactPreprocess.this, "More");
			}
//			v.setBackgroundColor(Color.WHITE);
		}
	};


	
	private OnClickListener viewListener = new OnClickListener()
	{
		public void onClick(View v)
		{  
//			v.setBackgroundColor(Color.GREEN);
			int viewId = v.getId();
			if (viewId == R.id.rl_precontact_chat){
				Intent intent = new Intent(ContactPreprocess.this, ChatActivity.class);
				startActivity(intent);
			}else if(viewId == R.id.rl_precontact_writemail){
				Intent intent = new Intent(ContactPreprocess.this, Mailboxes.class);
				startActivity(intent);
			}else if(viewId == R.id.rl_precontact_callmobile){
				DialogTool.showInfo(ContactPreprocess.this, "Call Mobile");
			}else if(viewId == R.id.rl_precontact_sendsms){
				DialogTool.showInfo(ContactPreprocess.this, "Send SMS");
			}else if(viewId == R.id.rl_precontact_calloffice){
				DialogTool.showInfo(ContactPreprocess.this, "Call Office");
			}else if(viewId == R.id.rl_precontact_callhome){
				DialogTool.showInfo(ContactPreprocess.this, "Call Home");
			}else if(viewId == R.id.rl_precontact_edit){
				DialogTool.showInfo(ContactPreprocess.this, "Edit");
			}else{
				DialogTool.showInfo(ContactPreprocess.this, "Edit");
			}
//			v.setBackgroundColor(Color.WHITE);
		}
	};

}
