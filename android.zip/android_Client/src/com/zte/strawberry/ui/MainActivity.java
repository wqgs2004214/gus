package com.zte.strawberry.ui;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Contacts.People;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Gallery;
import android.widget.SimpleCursorAdapter;
import android.widget.SpinnerAdapter;

import com.zte.strawberry.ui.tool.DialogTool;

@SuppressWarnings("deprecation")
public class MainActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		Cursor cur_people = getContentResolver().query(People.CONTENT_URI, null, null, null, null);
        startManagingCursor(cur_people);
        
        SpinnerAdapter spin_adapter = new SimpleCursorAdapter(this,
        // Use a template that displays a text view
                android.R.layout.simple_gallery_item,
                // Give the cursor to the list adatper
                cur_people,
                // Map the NAME column in the people database to...
                new String[] {People.NAME},
                // The "text1" view defined in the XML template
                new int[] { android.R.id.text1 });

        Gallery gly = (Gallery) findViewById(R.id.gly_chat_header_007);
        
        Log.d("show gly", "show gly");
		Log.d("show gly", String.valueOf(spin_adapter.getCount()));
//        ToolUI.showInfo(this,String.valueOf(spin_adapter.getCount()));
        
        gly.setAdapter(spin_adapter);
        
        gly.setOnItemClickListener(new OnItemClickListener() {
            @SuppressWarnings("rawtypes")
			public void onItemClick(AdapterView parent, View v, int position, long id) {
            	DialogTool.showInfo(MainActivity.this,"contact");
            }
        });
	
	}

}