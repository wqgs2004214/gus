package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class AddMailChoose extends Activity {

	Button button_more;
//	ImageButton btnAddGmail;
	
	ListView lv_mail;	
	private String selectedTitle = "add ?";
	public static Context mailChooseContext;
	private List<Map<String, Object>> mailList;
	
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.main_menu,
			R.menu.save_menu };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addemailchoose);
		
		button_more = (Button) findViewById(R.id.btn_choosemail_more);
		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				AddMailChoose.this.openOptionsMenu();
			}
		});
		
		lv_mail = (ListView)this.findViewById(R.id.lv_mail_choose);
		mailList = getData();
		
		SimpleAdapter adapter = new SimpleAdapter(this, mailList, R.layout.addemail_item,
				new String[] { "icon" , "line"},//
				new int[] { R.id.iv_lv_mail_icon ,R.id.tv_mailchoose_line });//		
		lv_mail.setAdapter(adapter);
		
		lv_mail.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.v("MailListView-click", (String) mailList.get(position).get("title"));
				selectedTitle = (String) mailList.get(position).get("title");
				
				if(selectedTitle == "other"){
					showInfo();
				}
				else {
					Intent intent = new Intent();
					intent.setClass(AddMailChoose.this, Strawberry.class);
					startActivity(intent);
				}
			}
        });
		
//		btnAddGmail = (ImageButton) findViewById(R.id.btn_add_gmail);
//        btnAddGmail.setOnClickListener(new OnClickListener() {
//            public void onClick(View v) {
////            	btnAddGmail.setBackgroundColor(R.color.LOWGRAY);
//    			Intent intent = new Intent();
//    			intent.setClass(AddMailChoose.this, AddMailDetail01.class);
//    			startActivity(intent);
////    			btnAddGmail.setBackgroundColor(R.color.WHITE);
//            }
//        });
//        
//        Button btnAddMSN = (Button) findViewById(R.id.btn_add_msn);
//        btnAddMSN.setOnClickListener(new OnClickListener() {
//            public void onClick(View v) {
//    			Intent intent = new Intent();
//    			intent.setClass(AddMailChoose.this, AddMailDetail01.class);
//    			startActivity(intent);
//            }
//        });
//        
//        Button btnAddYahoo = (Button) findViewById(R.id.btn_add_yahoo);
//        btnAddYahoo.setOnClickListener(new OnClickListener() {
//            public void onClick(View v) {
//    			Intent intent = new Intent();
//    			intent.setClass(AddMailChoose.this, AddMailDetail01.class);
//    			startActivity(intent);
//            }
//        });
//        
//        Button btnAddExchange = (Button) findViewById(R.id.btn_add_exchange);
//        btnAddExchange.setOnClickListener(new OnClickListener() {
//            public void onClick(View v) {
//    			Intent intent = new Intent();
//    			intent.setClass(AddMailChoose.this, AddMailDetail01.class);
//    			startActivity(intent);
//            }
//        });
//        
//        Button btnAddOther = (Button) findViewById(R.id.btn_add_other);
//        btnAddOther.setOnClickListener(new OnClickListener() {
//            public void onClick(View v) {
//    			Intent intent = new Intent();
//    			intent.setClass(AddMailChoose.this, AddMailDetail01.class);
//    			startActivity(intent);
//            }
//        });
        
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_a01:// 應用退出
			this.finish();
			// android.os.Process.killProcess(android.os.Process.myPid());
			// System.exit(0);
			break;
		case R.id.menu_a02:// 跳轉到分類列表的頁面
			Intent toAbout = new Intent(this, AboutActivity.class);
			this.startActivity(toAbout);
			break;
		// case R.id.menu_a03:// help 顯示一個dialog
		// this.showDialog(R.id.menu_a02);
		// break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		this.findViewById(keyCode).setBackgroundColor(R.color.LOWGRAY);
//		return super.onKeyDown(keyCode, event);
//	}
	
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("icon", R.drawable.gmail);
		map.put("line", R.color.GRAY);
		map.put("title", "gmail");
		list.add(map);
		
		map = new HashMap<String, Object>();
		map.put("icon", R.drawable.msn);
		map.put("line", R.color.GRAY);
		map.put("title", "msn");
		list.add(map);
		
		map = new HashMap<String, Object>();
		map.put("icon", R.drawable.yahoo);
		map.put("line", R.color.GRAY);
		map.put("title", "yahoo");
		list.add(map);
		
		map = new HashMap<String, Object>();
		map.put("icon", R.drawable.exchange);
		map.put("line", R.color.GRAY);
		map.put("title", "exchange");
		list.add(map);
		
		map = new HashMap<String, Object>();
		map.put("icon", R.drawable.other);
		map.put("line", R.color.GRAY);
		map.put("title", "other");
		list.add(map);

		return list;
	}

//	listview中点击按键弹出对话框
	public void showInfo() {
		new AlertDialog.Builder(this).setTitle("Add mail guide")
				.setMessage(selectedTitle)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					}
				}).show();
		
		//跳转到添加邮件界面
		Intent intent = new Intent();
		intent.setClass(AddMailChoose.this, AddMailDetail01.class);
		startActivity(intent);
	}

}
