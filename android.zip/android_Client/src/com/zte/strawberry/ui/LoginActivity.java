package com.zte.strawberry.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginActivity extends Activity {

	Button button_login;
	Button button_more;
	Button button_register;
	TextView tv_succeful;

	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.main_menu,
			R.menu.save_menu };

	// private int GROUP_MAIN_MENU = 0; //主菜单

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		button_login = (Button) findViewById(R.id.btn_login);
		button_more = (Button) findViewById(R.id.btn_login_more);
		button_register = (Button) findViewById(R.id.btn_register);
//		tv_succeful = (TextView) findViewById(R.id.tv_succeful_view);
//		button_login.setBackgroundColor(Color.GREEN);

		button_login.setOnClickListener(login_clickListener);
		button_more.setOnClickListener(more_clickListener);
		button_register.setOnClickListener(register_clickListener);

		if (myMenu != null) {
			onCreateOptionsMenu(myMenu);
		}
	}

	private Button.OnClickListener login_clickListener = new Button.OnClickListener() {
		public void onClick(View view) {
			Intent intent = new Intent();
			intent.setClass(LoginActivity.this, LoginingActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener register_clickListener = new Button.OnClickListener() {
		public void onClick(View view) {
			showTipDialog();
		}
	};

	private Button.OnClickListener more_clickListener = new Button.OnClickListener() {
		public void onClick(View view) {
			// 显示菜单
			// super.onKeyUp(KeyEvent.KEYCODE_MENU, event);
			// myMenu.setGroupVisible(R.id.menu_group_a, true);
			// myMenu.setGroupVisible(R.menu.main_menu, true);

			LoginActivity.this.openOptionsMenu();
		}
	};

	private void showTipDialog() {
		this.showDialog(R.id.menu_a02);
	}

	private Dialog buildHelpDialog(Context context) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle("Welcome");

		// 以列表方式尝试白背景
		// builder.setIcon(R.drawable.infotitle);
		// builder.setItems(R.array.select_dialog_items, new
		// DialogInterface.OnClickListener() {
		// public void onClick(DialogInterface arg0, int arg1) {}
		// });

		// 以view方式尝试白背景
		// Context mContext = getApplicationContext();
		// LayoutInflater inflater = (LayoutInflater)
		// mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
		// View layout = inflater.inflate(R.layout.succefulview,(ViewGroup)
		// findViewById(R.id.view_group_succeful));
		// TextView text01 = (TextView)
		// layout.findViewById(R.id.tv_succeful_view01);
		// TextView text02 = (TextView)
		// layout.findViewById(R.id.tv_succeful_view02);
		// TextView text03 = (TextView)
		// layout.findViewById(R.id.tv_succeful_view03);
		// builder.setView(layout);

		builder.setMessage(R.string.register_succeed_tip);
		builder.setNegativeButton("OK", null);
		return builder.create();
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case R.id.menu_a02:
			return buildHelpDialog(this);
		}
		return super.onCreateDialog(id);
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_a01:// 應用退出
			this.finish();
			// android.os.Process.killProcess(android.os.Process.myPid());
			// System.exit(0);
			break;
		case R.id.menu_a02:// 跳轉到分類列表的頁面
			Intent toAbout = new Intent(this, AboutActivity.class);
			this.startActivity(toAbout);
			break;
		// case R.id.menu_a03:// help 顯示一個dialog
		// this.showDialog(R.id.menu_a02);
		// break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

}
