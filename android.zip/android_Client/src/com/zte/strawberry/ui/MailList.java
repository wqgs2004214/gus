package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.zte.strawberry.ui.tool.DialogTool;

public class MailList extends Activity {

	Button button_home;
	Button button_refresh;
	Button button_compose;
	Button button_more;
	Button button_back;
	
	ListView lv_mail;
	
	public static Context maillistContext;
	private ArrayList<HashMap<String, Object>> mailList;
//	private String selectedTitle = "add ?";
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.main_menu,
			R.menu.save_menu };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mail_list);
		    
		button_home = (Button) findViewById(R.id.btn_maillist_home);
		button_refresh = (Button) findViewById(R.id.btn_maillist_refresh);	
		button_compose = (Button) findViewById(R.id.btn_maillist_compose);
		button_more = (Button) findViewById(R.id.btn_maillist_more);
		button_back = (Button) findViewById(R.id.btn_maillist_back);
		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				MailList.this.openOptionsMenu();
			}
		});
		
		button_home.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent(MailList.this, Strawberry.class);
        		startActivity(intent);
			}
		});
		
		button_refresh.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent(MailList.this, SingleMail.class);
        		startActivity(intent);
			}
		});
		
		maillistContext=this;
		lv_mail= (ListView)findViewById(R.id.lv_mail_list);
		mailList = getMailList();
		
		SimpleAdapter mailAdapter = new SimpleAdapter(this, mailList, R.layout.mail_item,
				new String[] { "MailTitle" , "MailSummary" , "MailAddresser", "MailDate"},//
				new int[] { R.id.tv_mail_title ,R.id.tv_mail_summary ,R.id.tv_mail_addresser , R.id.tv_mail_date });
		
		lv_mail.setAdapter(mailAdapter);
		
		lv_mail.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0,View arg1,int arg2,long arg3) {
//				@SuppressWarnings("unchecked")
//				HashMap<String, Object> item = (HashMap<String, Object>) arg0.getItemAtPosition(arg2);
				// 显示所选Item的ItemText
				DialogTool.showInfo(MailList.this, "Mail");
			}
        });
	
		
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_a01:// 應用退出
			this.finish();
			// android.os.Process.killProcess(android.os.Process.myPid());
			// System.exit(0);
			break;
		case R.id.menu_a02:// 跳轉到分類列表的頁面
			Intent toAbout = new Intent(this, AboutActivity.class);
			this.startActivity(toAbout);
			break;
		// case R.id.menu_a03:// help 顯示一個dialog
		// this.showDialog(R.id.menu_a02);
		// break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private ArrayList<HashMap<String, Object>> getMailList(){
		ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("MailTitle", "国庆放假通知国庆放假通知国庆放假通知");//添加项目图标
		map.put("MailSummary", null);////添加项目标题
		map.put("MailAddresser", ">tina");////添加项目标题
		map.put("MailDate","9.Oct");
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailTitle", "国庆放假通知");//添加项目图标
		map.put("MailSummary", "你好，关于国庆放假调整，…");////添加项目标题
		map.put("MailAddresser", ">tina");////添加项目标题
		map.put("MailDate","9.Oct");
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailTitle", "国庆放假通知");//添加项目图标
		map.put("MailSummary", "你好，关于国庆放假调整，…");////添加项目标题
		map.put("MailAddresser", ">tina");////添加项目标题
		map.put("MailDate","9.Oct");
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailTitle", "国庆放假通知");//添加项目图标
		map.put("MailSummary", "你好，关于国庆放假调整，…");////添加项目标题
		map.put("MailAddresser", ">tina");////添加项目标题
		map.put("MailDate","9.Oct");
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailTitle", "国庆放假通知");//添加项目图标
		map.put("MailSummary", "你好，关于国庆放假调整，…");////添加项目标题
		map.put("MailAddresser", ">tina");////添加项目标题
		map.put("MailDate","9.Oct");
    	lstImageItem.add(map);
    	
        return lstImageItem;
	}


}