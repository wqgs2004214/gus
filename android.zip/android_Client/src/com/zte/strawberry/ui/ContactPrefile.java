package com.zte.strawberry.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ContactPrefile extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contact_prefile);
		
		Button btnHome = (Button)findViewById(R.id.btn_contprefile_home);
		Button btnMore = (Button)findViewById(R.id.btn_contprefile_more);
		Button btnRefresh = (Button)findViewById(R.id.btn_contprefile_refresh);
		
		btnRefresh.setOnClickListener(buttonListener);
		btnHome.setOnClickListener(buttonListener);
		btnMore.setOnClickListener(buttonListener);
	}

	private OnClickListener buttonListener = new OnClickListener()
	{
		public void onClick(View v)
		{  
//			v.setBackgroundColor(Color.GREEN);
			int btnId = v.getId();
			if (btnId == R.id.btn_contprefile_refresh ){
				Intent intent = new Intent(ContactPrefile.this, ChatActivity.class);
				startActivity(intent);
			}else if (btnId == R.id.btn_contprefile_home){
				Intent intent = new Intent(ContactPrefile.this, Strawberry.class);
				startActivity(intent);
			}else{
				Intent intent = new Intent();
				intent.setClass(ContactPrefile.this, ChatActivity.class);
				startActivity(intent);
			}
//			v.setBackgroundColor(Color.WHITE);
		}
	};
}
