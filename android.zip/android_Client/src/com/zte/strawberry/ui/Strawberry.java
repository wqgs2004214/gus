package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;
import com.zte.strawberry.config.Configuration;
import com.zte.strawberry.mainMenuUI.ActivityMain;
import com.zte.strawberry.utils.StringTokenizer;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class Strawberry extends Activity implements Runnable{
	public static Strawberry strawberry;
	public ActivityMain mainMenu; //主界面
	
	Button button_more;
	GridView gv_strawberryList;
	
	public static Context strawberryContext;
	private List<HashMap<String, Object>> strawberryList;
	private String selectedTitle = "add ?";
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.main_menu,
			R.menu.save_menu };
	
	/**
	 * 初始化strawberry应用程序,jvm启动时默认加载strawberry构造函数,构造函数必须设置成public
	 */
	public Strawberry() {
		Strawberry.strawberry = this;
		this.mainMenu = new ActivityMain(this);
	}
	
	/**
	 * 初始化主程序,启动顺序依次为:
	 * 1、加载AboutActivity界面
	 * 2、加载类实例(contact;chat;community;email;files;)
	 */
	public void init() {
		//TODO:加载AboutActivity界面
		//显示首次加载时候提示
		if(false){
			//TODO:添加首次加载提示框
		} else {  //不加载首次提示框
			new Thread(this).start();
		}
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.strawberry);
		
		button_more = (Button) findViewById(R.id.btn_strawberry_more);		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Strawberry.this.openOptionsMenu();
			}
		});
		
		strawberryContext=this;
		gv_strawberryList= (GridView)findViewById(R.id.gv_strawberry_list);
		strawberryList=getData();
		
		gv_strawberryList.setAdapter(new GuideChanelAdapter(Strawberry.this, strawberryList));
		
		gv_strawberryList.setOnItemClickListener(new OnItemClickListener() {
			@SuppressWarnings("unchecked")
			public void onItemClick(AdapterView<?> arg0,// The AdapterView where the click happened
												View arg1,// The view within the AdapterView that was clicked
												int arg2,// The position of the view in the adapter
												long arg3// The row id of the item that was clicked
			) {
				// 在本例中arg2=arg3
				HashMap<String, Object> item = (HashMap<String, Object>) arg0.getItemAtPosition(arg2);
				// 显示所选Item的ItemText
				setTitle((String) item.get("ItemText"));
				selectedTitle = (String) item.get("ItemText");
				if(selectedTitle == "Chat"){
					Intent intent = new Intent(Strawberry.this, ChatActivity.class);
					startActivity(intent);
				}else if (selectedTitle == "Setting"){
					Intent intent = new Intent(Strawberry.this, Setting.class);
					startActivity(intent);
				}else if (selectedTitle == "Email"){
					Intent intent = new Intent(Strawberry.this, Mailboxes.class);
					startActivity(intent);
				}else showInfo();
				
				Log.i("sbGridView-click", (String) item.get("ItemText"));
			}
        });
	}
	
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_a01:// 應用退出
			this.finish();
			// android.os.Process.killProcess(android.os.Process.myPid());
			// System.exit(0);
			break;
		case R.id.menu_a02:// 跳轉到分類列表的頁面
			Intent toAbout = new Intent(this, AboutActivity.class);
			this.startActivity(toAbout);
			break;
		// case R.id.menu_a03:// help 顯示一個dialog
		// this.showDialog(R.id.menu_a02);
		// break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	//gridview中点击按键弹出对话框
	public void showInfo() {		
//		new AlertDialog.Builder(Strawberry.this)
//        .setTitle(selectedTitle)
//        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int whichButton) {
//            }
//        })
//        .setItems(R.array.imp_contact_from_items, new DialogInterface.OnClickListener() {
//            public void onClick(DialogInterface dialog, int which) {
//                /* User clicked so do some stuff */
//                String[] items = getResources().getStringArray(R.array.imp_contact_from_items);
//                new AlertDialog.Builder(Strawberry.this)
//                        .setMessage("You selected: " + which + " , " + items[which]
//                        ).show();
//            }
//        }).show();
		
		Intent intent = new Intent(Strawberry.this, ImportContact.class);
		startActivity(intent);
	}

	private ArrayList<HashMap<String, Object>> getData(){
		ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.contact);//添加项目图标
		map.put("ItemText", "Contact");////添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.chat);//添加项目图标
		map.put("ItemText", "Chat");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.community);//添加项目图标
		map.put("ItemText", "Community");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.email);//添加项目图标
		map.put("ItemText", "Email");///添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.help);//添加项目图标
		map.put("ItemText", "Help");///添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.setting);//添加项目图标
		map.put("ItemText", "Setting");//添加项目标题
    	lstImageItem.add(map);
        
        return lstImageItem;
	}
	
	public static class GuideChanelAdapter extends BaseAdapter {
	
		private List<HashMap<String, Object>> listData;
		private Context currentContext;
		
		public GuideChanelAdapter(Context context, List<HashMap<String, Object>> list)
		{
			listData = list;
			currentContext = context;
		}		
		public int getCount() {
			return listData.size();
		}

		public Object getItem(int position) {
			return listData.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
	            convertView = LayoutInflater.from(currentContext).inflate(R.layout.strawberry_item, null);
	            
	            holder = new ViewHolder();
	            holder.imge = (ImageView) convertView.findViewById(R.id.strawberry_item_image);
	            holder.title = (TextView) convertView.findViewById(R.id.strawberry_item_title);
	            
	            convertView.setTag(holder);
	        } else {
	            holder = (ViewHolder) convertView.getTag();
	        }	        
			
			HashMap<String, Object> hashMap = listData.get(position);
			int imgeId = (Integer)hashMap.get("ItemImage");
			String title  =(String) hashMap.get("ItemText");
			Log.d("holder", (holder == null) ? "holder is null":"hoder is not null");
			holder.imge.setBackgroundResource(imgeId);
			holder.title.setText(title);
			Log.d("imgid",((Integer)imgeId).toString());
			
	        return convertView;
		}
		
		static class ViewHolder {
	        TextView title;
	        ImageView imge;
	    }
	}
	
	/**
	 * 
	 * @param defaultComponents 需要加载的组件值,eg：contact;chat;community;email;files;
	 * @return 拆分后的组件
	 */
	private Vector<String> getAllComponentsForSelection(String defaultComponets) {
		Vector<String> all = new Vector<String>();
        StringTokenizer st = new StringTokenizer(defaultComponets, ";");
        while(st.hasMoreElements()) {
            String name = st.nextToken();
            all.addElement(name);
        }
        return all;
    }
	
	/**
	 * 加载组件
	 * @param names 组件名
	 */
	private void loadComponents(Vector<String> names) {
		mainMenu.removeAllComponents();
		
	}
	
	
	@Override
	
	public void run() {
		loadComponents(getAllComponentsForSelection(Configuration.C));
		
	}

}
