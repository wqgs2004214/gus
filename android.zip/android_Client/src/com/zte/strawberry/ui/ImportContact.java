package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Contacts.People;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.zte.strawberry.dataset.DataManage;
import com.zte.strawberry.ui.tool.DialogTool;

@SuppressWarnings("deprecation")
public class ImportContact extends Activity {


	Button button_more;
	Button button_save;
	ListView lv_sim_contact;
	
	private String selectedTitle = "add ?";
	public static Context impContactContext;
	private ArrayList<HashMap<String, Object>> contactList;
	
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { 
		R.menu.select_menu,R.menu.main_menu,R.menu.save_menu };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contact_import);
		
		button_more = (Button) findViewById(R.id.btn_impcont_more);
		button_save = (Button) findViewById(R.id.btn_impcont_save);		
		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				ImportContact.this.openOptionsMenu();
			}
		});
		
		button_save.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent();
				intent.setClass(ImportContact.this, StbyContacts.class);
				startActivity(intent);
			}
		});
		
		lv_sim_contact = (ListView)this.findViewById(R.id.lv_simcontact_list);
		
//		contactList = getData();
//		SimpleAdapter adapter = new SimpleAdapter(this, contactList, R.layout.sim_contact_item,
//				new String[] { "icon", "line" },
//				new int[] { R.id.iv_lv_mail_icon,R.id.tv_mailchoose_line });		
//		lv_sim_contact.setAdapter(adapter);
		
//		Cursor cursor = getContentResolver().query(People.CONTENT_URI, null, null, null, null);
//		startManagingCursor(cursor);
//		
//        ListAdapter listAdapter = new SimpleCursorAdapter(this, R.layout.contact_sim_item,
//        		                cursor,
//        		                new String[]{People.NAME},
//        		                new int[]{R.id.sim_contact_name});
//
//        lv_sim_contact.setAdapter(listAdapter);

        contactList = DataManage.getContacts();
        ListAdapter listAdapter = new SimpleAdapter(this, contactList, R.layout.contact_sim_item,
				new String[] { "Name" },//
				new int[] { R.id.sim_contact_name  });//		
        lv_sim_contact.setAdapter(listAdapter);
        
        
		lv_sim_contact.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//				Log.v("MailListView-click", (String) contactList.get(position).get("name"));
//				selectedTitle = (String) contactList.get(position).get("name");
//				showInfo();
				
				DialogTool.showInfo(ImportContact.this, "click sim contact");
			}
        });
		
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.select_menu, true);
			menu.setGroupVisible(R.menu.main_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.select_menu, true);
			menu.setGroupVisible(R.menu.main_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_select_all:
			DialogTool.showInfo(this, "menu_select_all");
			break;
		case R.id.menu_cancel_all:
			DialogTool.showInfo(this, "menu_cancel_all");
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		this.findViewById(keyCode).setBackgroundColor(R.color.LOWGRAY);
//		return super.onKeyDown(keyCode, event);
//	}
	
	@SuppressWarnings("unused")
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("icon", R.drawable.gmail);
		map.put("line", R.color.GRAY);
		map.put("title", "gmail");
		list.add(map);
		map = new HashMap<String, Object>();
		map.put("icon", R.drawable.other);
		map.put("line", R.color.GRAY);
		map.put("title", "other");
		list.add(map);
		
		Cursor cursor = getContentResolver().query(People.CONTENT_URI, null, null, null, null);
		startManagingCursor(cursor);

		return list;
	}

//	listview中点击按键弹出对话框
	public void showInfo() {
		new AlertDialog.Builder(this).setTitle("Select contacts")
				.setMessage(selectedTitle)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					}
				}).show();
		
		//跳转到添加邮件界面
		Intent intent = new Intent();
		intent.setClass(ImportContact.this, AddMailDetail01.class);
		startActivity(intent);
	}

}
