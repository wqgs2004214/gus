package com.zte.strawberry.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class LoginingActivity extends Activity {

	private Button btn_return;
	private ProgressBar mProgressBar;
    private int mProgress;
    private Handler mProgressHandler;
    private static final int MAX_PROGRESS = 30;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.logining);

		btn_return = (Button) findViewById(R.id.btn_logining_back);
		btn_return.setOnClickListener(return_clickListener);
		
	    //模拟登陆连网进度处理   
        mProgressHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (mProgress >= MAX_PROGRESS) {                   
                    // 登陆成功后转到主界面
            		Intent intent = new Intent(LoginingActivity.this, Strawberry.class);
//            		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            		startActivity(intent);
                } else {
                    mProgress++;
                    mProgressBar.incrementProgressBy(1);
                    mProgressHandler.sendEmptyMessageDelayed(0, 100);
                }
            }
        };
        
        //模拟登陆进度
		simulateProgress();
	}

	private Button.OnClickListener return_clickListener = new Button.OnClickListener() {
		public void onClick(View view) {
			Intent intent = new Intent();
			intent.setClass(LoginingActivity.this, LoginActivity.class);
			startActivity(intent);
		}
	};

//	@Override
//	// 按下任意键跳转到向导界面
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		Intent intent = new Intent();
//		intent.setClass(LoginingActivity.this, GuideActivity.class);
//		startActivity(intent);
//		return super.onKeyDown(keyCode, event);
//	}
	
	//模拟登陆进度
	public void simulateProgress(){
		mProgressBar = (ProgressBar)findViewById(R.id.progressbar_login);;
		mProgressBar.setMax(MAX_PROGRESS);        
        mProgress = 0;
        mProgressBar.setProgress(0);
        mProgressHandler.sendEmptyMessage(0);
	}
	
}
