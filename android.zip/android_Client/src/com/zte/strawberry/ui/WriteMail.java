package com.zte.strawberry.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.EditText;

public class WriteMail extends Activity {
	
	View viewCcbcc;
	View viewCc ;
	View viewBcc; 
	EditText etCcbcc;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.write_mail);
		
		viewCcbcc = (View) findViewById(R.id.rl_writemail_ccbcc);
		viewCc = (View) findViewById(R.id.rl_writemail_cc);
		viewBcc = (View) findViewById(R.id.rl_writemail_bcc);
		etCcbcc = (EditText) findViewById(R.id.et_writemail_ccbcc);
		
		viewCcbcc.setOnClickListener(ccbccClickListener);
		etCcbcc.setOnClickListener(ccbccClickListener);
		
		viewCcbcc.setOnTouchListener(ccbccTouchListener);
		etCcbcc.setOnTouchListener(ccbccTouchListener);
	}
	
	private OnClickListener ccbccClickListener = new OnClickListener() {
		public void onClick(View view) {
//			DialogTool.showInfo(WriteMail.this, "Click");
			viewCcbcc.setVisibility(View.GONE);
			viewCc.setVisibility(View.VISIBLE);
			viewBcc.setVisibility(View.VISIBLE);
		}
	};
	
	private OnTouchListener ccbccTouchListener = new OnTouchListener() {
		public boolean onTouch(View v, MotionEvent event) {
//			DialogTool.showInfo(WriteMail.this, "Click");
			viewCcbcc.setVisibility(View.GONE);
			viewCc.setVisibility(View.VISIBLE);
			viewBcc.setVisibility(View.VISIBLE);
			return false;
		}
	};
}