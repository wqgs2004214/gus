package com.zte.strawberry.ui;

import android.app.Activity;
import android.os.Bundle;

public class AddMailDetail extends Activity {
	/**
	 * @see android.app.Activity#onCreate(Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addemaildetail);
		
	}

}
