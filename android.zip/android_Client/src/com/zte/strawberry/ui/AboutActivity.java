package com.zte.strawberry.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.Intent.ShortcutIconResource;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;

public class AboutActivity extends Activity {
	/** Called when the activity is first created. */
	

	private ProgressDialog mProgressDialog;
    private int mProgress;   
    private Handler mProgressHandler;
    private static final int MAX_PROGRESS = 20;
    
    public AboutActivity() {
    
    }
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);

		//在桌面添加快捷方式
//		new ToolUI().addShortcut();
		addShortcut();

	    //模拟登陆连网进度处理   
        mProgressHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (mProgress >= MAX_PROGRESS) {
                    mProgressDialog.dismiss();
                    
                    // 网络连上后跳转到登陆界面
            		Intent intent = new Intent(AboutActivity.this, LoginActivity.class);
            		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            		startActivity(intent);
            		
                } else {
                    mProgress++;
                    mProgressDialog.incrementProgressBy(1);
                    mProgressHandler.sendEmptyMessageDelayed(0, 100);
                }
            }
        };
        
        //模拟登陆连网进度处理   
		simulateProgress();
	}

	// 按下任意键跳转到登陆界面
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		Intent intent = new Intent(AboutActivity.this, LoginActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
		return super.onKeyDown(keyCode, event);
	}

	// 界面暂停
	public void activitySleep(int ms) {
		try {
			Thread.sleep(ms);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//模拟登陆连网进度处理   
	public void simulateProgress(){
        mProgressDialog = new ProgressDialog(AboutActivity.this);

        mProgressDialog.setMax(MAX_PROGRESS);
        
        mProgressDialog.hide();        
//        mProgressDialog.show();
        
        mProgress = 0;
        mProgressDialog.setProgress(0);
        mProgressHandler.sendEmptyMessage(0);
	}
	

	/**
	 * 为程序创建桌面快捷方式
	 */
	@SuppressWarnings(value = {})
	public void addShortcut(){
		Intent shortcut = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
			
		//快捷方式的名称
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.app_name));
		shortcut.putExtra("duplicate", false); //不允许重复创建
			
		//指定当前的Activity为快捷方式启动的对象: 如 com.everest.video.VideoPlayer
		//注意: ComponentName的第二个参数必须加上点号(.)，否则快捷方式无法启动相应程序
		ComponentName comp = new ComponentName(this.getPackageName(), "."+this.getLocalClassName());
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_INTENT, new Intent(Intent.ACTION_MAIN).setComponent(comp));

		//快捷方式的图标
		ShortcutIconResource iconRes = Intent.ShortcutIconResource.fromContext(this, R.drawable.icon);
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, iconRes);
			
		sendBroadcast(shortcut);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}

	/**
	 * 删除程序的快捷方式
	 */
	public void delShortcut(){
		Intent shortcut = new Intent("com.android.launcher.action.UNINSTALL_SHORTCUT");
			
		//快捷方式的名称
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.app_name));
			
		//指定当前的Activity为快捷方式启动的对象: 如 com.everest.video.VideoPlayer
		//注意: ComponentName的第二个参数必须是完整的类名（包名+类名），否则无法删除快捷方式
		String appClass = this.getPackageName() + "." +this.getLocalClassName();
		ComponentName comp = new ComponentName(this.getPackageName(), appClass);
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_INTENT, new Intent(Intent.ACTION_MAIN).setComponent(comp));
		
		sendBroadcast(shortcut);	
	}
	
	
	
}