package com.zte.strawberry.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.view.View.OnClickListener;

public class SingleMail extends Activity {
	
	Button button_reply01;
	Button button_replyAll01;
	Button button_reply;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.single_mail);

		button_reply = (Button) findViewById(R.id.btn_singlemail_reply);
		button_reply01 = (Button) findViewById(R.id.btn_singlemail_reply01);
		button_replyAll01 = (Button) findViewById(R.id.btn_singlemail_replyall01);
		
		button_reply.setOnClickListener(clickListener);
		button_reply01.setOnClickListener(clickListener);
		button_replyAll01.setOnClickListener(clickListener);
	}
	
	private OnClickListener clickListener = new OnClickListener() {
		public void onClick(View view) {
			Intent intent = new Intent(SingleMail.this, WriteMail.class);
    		startActivity(intent);
		}
	};

}