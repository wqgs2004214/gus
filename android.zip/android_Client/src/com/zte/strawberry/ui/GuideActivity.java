package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class GuideActivity extends Activity {

	Button button_logout;
	Button button_more;
	ListView lv_guidelist;
	
	public static Context guideContext;
	private List<Map<String, Object>> guideList;
	@SuppressWarnings("unused")
	private String selectedTitle = "add ?";
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.main_menu,
			R.menu.save_menu };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.guideindex);
		guideContext = this;	
		
		button_logout = (Button) findViewById(R.id.btn_guide_logout);
		button_more = (Button) findViewById(R.id.btn_guide_more);
        
		lv_guidelist = (ListView)this.findViewById(R.id.lv_guide_list);
		guideList = getData();
		
//		SimpleAdapter adapter = new SimpleAdapter(this, guidelist, R.layout.guide_index_item,
//				new String[] { "title", "info", "img" },
//				new int[] { R.id.tv_lv_guideindex_title,R.id.tv_lv_guideindex_info, R.id.iv_lv_guideindex_icon });		
//		lv_guidelist.setAdapter(adapter);
		
		lv_guidelist.setAdapter(new GuideChanelAdapter(GuideActivity.this, guideList));
		lv_guidelist.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.v("GuideListView-click", (String) guideList.get(position).get("title"));
				selectedTitle = (String) guideList.get(position).get("title");
				showInfo();
			}
        });
		
		button_logout.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				GuideActivity.this.finish();
			}
		});
		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				GuideActivity.this.openOptionsMenu();
			}
		});
	}
	
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("title", "Add chat account");
		map.put("info", "Add your MSN or Yahoo account here.");
		map.put("img", R.drawable.index_icon01);
		map.put("line", R.color.GRAY);
		list.add(map);

		map = new HashMap<String, Object>();
		map.put("title", "Add email account");
		map.put("info", "Add your email account.");
		map.put("img", R.drawable.index_icon02);
		map.put("line", R.color.GRAY);
		list.add(map);

		return list;
	}

//	listview中点击按键弹出对话框
	public void showInfo() {
//		new AlertDialog.Builder(this).setTitle("Add account guide")
//				.setMessage(selectedTitle)
//				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//					public void onClick(DialogInterface dialog, int which) {
//					}
//				}).show();
		
		//跳转到添加邮件界面
		Intent intent = new Intent();
		intent.setClass(GuideActivity.this, AddMailChoose.class);
		startActivity(intent);
	}
	
	public static class GuideChanelAdapter extends BaseAdapter {
//		public static class GuideChanelAdapter extends SimpleAdapter {
//		public GuideChanelAdapter(Context context,
//				List<Map<String, Object>> data) {
//			super(context, data, R.layout.guide_index_item, new String[] {
//					"title", "info", "img" }, new int[] {
//					R.id.tv_lv_guideindex_title, R.id.tv_lv_guideindex_info,
//					R.id.iv_lv_guideindex_icon });
//		}		
		private List<Map<String, Object>> listData;
		private Context currentContext;
		public GuideChanelAdapter(Context context, List<Map<String, Object>> list)
		{
			listData = list;
			currentContext = context;
		}		
		public int getCount() {
			return listData.size();
		}

		public Object getItem(int position) {
			return listData.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
	            convertView = LayoutInflater.from(currentContext).inflate(R.layout.guide_index_item, null);
	            
	            holder = new ViewHolder();
	            holder.img = (ImageView) convertView.findViewById(R.id.iv_lv_guideindex_icon);
	            holder.info = (TextView) convertView.findViewById(R.id.tv_lv_guideindex_info);
	            holder.title = (TextView) convertView.findViewById(R.id.tv_lv_guideindex_title);
	            holder.line =  (TextView) convertView.findViewById(R.id.tv_interval_line);
	            
	            convertView.setTag(holder);
	        } else {
	            holder = (ViewHolder) convertView.getTag();
	        }	        
			
			Map<String, Object> map = listData.get(position);
			int imgId = (Integer)map.get("img");
			String info  =(String) map.get("info");
			String title  =(String) map.get("title");
			int linebg = (Integer)map.get("line");
			Log.d("holder", (holder == null) ? "holder is null":"hoder is not null");
			
			holder.img.setBackgroundResource(imgId);
			holder.info.setText(info);
			holder.title.setText(title);
			holder.line.setBackgroundColor(linebg);
			Log.d("after set map", (String)holder.info.getText());
			Log.d("imgid",((Integer)imgId).toString());
			
	        return convertView;
		}
		
		static class ViewHolder {
	        TextView title;
	        TextView info;
	        ImageView img;
	        TextView line;
	    }
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_a01:// 應用退出
			this.finish();
			// android.os.Process.killProcess(android.os.Process.myPid());
			// System.exit(0);
			break;
		case R.id.menu_a02:// 跳轉到分類列表的頁面
			Intent toAbout = new Intent(this, AboutActivity.class);
			this.startActivity(toAbout);
			break;
		// case R.id.menu_a03:// help 顯示一個dialog
		// this.showDialog(R.id.menu_a02);
		// break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

}
