package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.zte.strawberry.adapter.ContactAdapter;
import com.zte.strawberry.adapter.MessageAdapter;
import com.zte.strawberry.dataset.DataManage;
import com.zte.strawberry.ui.tool.DialogTool;

public class ChatActivity extends Activity {

	Button button_home;
	Button button_more;
	Button button_share;
	GridView gv_emotionList;
	ListView lv_messagesList;
	ImageView iv_emotion;
	View view_emotion;
	View view_bottom;
	Gallery gly;
	
	public static Context chatContext;
	private List<HashMap<String, Object>> emotionList;
	private List<HashMap<String, Object>> messageList;
	@SuppressWarnings("unused")
	private ArrayList<HashMap<String, Object>> contactList;
	private String selectedTitle = "add ?";
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.main_menu,
			R.menu.save_menu };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chat);
		
//		Cursor cur_people = getContentResolver().query(People.CONTENT_URI, null, null, null, null);
//        startManagingCursor(cur_people);
//        
//        SpinnerAdapter spin_adapter = new SimpleCursorAdapter(this,
//        // Use a template that displays a text view
//                R.layout.chat_header_item,
//                // Give the cursor to the list adatper
//                cur_people,
//                // Map the NAME column in the people database to...
//                new String[] {People.NAME},
//                // The "text1" view defined in the XML template
//                new int[] { R.id.tv_chat_header });
//
//        gly = (Gallery) findViewById(R.id.gly_chat_header);
//        gly.setAdapter(spin_adapter);  
//        gly.setSelection(0);
		
		// Reference the Gallery view
        gly = (Gallery) findViewById(R.id.gly_chat_header);
        // Set the adapter to our custom adapter (below)
        gly.setAdapter(new ContactAdapter(this));
        
        gly.setOnItemSelectedListener(new OnItemSelectedListener() {        	
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				if(1 == position){
					messageList = DataManage.getMessageData1();
					lv_messagesList.setAdapter(new MessageAdapter(ChatActivity.this, messageList));
				}
				else if(2 == position){
					messageList = DataManage.getMessageData2();
					lv_messagesList.setAdapter(new MessageAdapter(ChatActivity.this, messageList));
				}
				else{
					messageList = DataManage.getMessageData();
					lv_messagesList.setAdapter(new MessageAdapter(ChatActivity.this, messageList));
				}
//				gly.getSelectedView().setBackgroundResource(R.drawable.chat_header_glyitem);
			}

			public void onNothingSelected(AdapterView<?> parent) {
				messageList = DataManage.getMessageData();
				lv_messagesList.setAdapter(new MessageAdapter(ChatActivity.this, messageList));
			}
		});
        
        
        view_emotion = (View) findViewById(R.id.rl_choose_emotion);
        view_bottom = (View) findViewById(R.id.rl_chat_bottom);
        
        iv_emotion = (ImageView) findViewById(R.id.iv_chat_emotion);
        iv_emotion.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				if(view_emotion.getVisibility() == View.GONE){
					view_emotion.setVisibility(View.VISIBLE);
					view_bottom.setVisibility(View.GONE);
				}
				else {
					view_emotion.setVisibility(View.GONE);
					view_bottom.setVisibility(View.VISIBLE);
				}
			}
		});

		button_more = (Button) findViewById(R.id.btn_chat_more);	
		button_share = (Button) findViewById(R.id.btn_chat_share);
		button_home = (Button) findViewById(R.id.btn_chat_home);
		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				ChatActivity.this.openOptionsMenu();
			}
		});
		
		button_share.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
//				DialogTool.showInfo(ChatActivity.this, "send message");
				Intent intent = new Intent(ChatActivity.this, Mailboxes.class);
        		startActivity(intent);
			}
		});
		
		button_share.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent(ChatActivity.this, Strawberry.class);
        		startActivity(intent);
			}
		});
		
		chatContext=this;
		gv_emotionList= (GridView)findViewById(R.id.gv_emotion_list);
		lv_messagesList = (ListView)findViewById(R.id.lv_chat_message);
		emotionList = getEmotionData();
		messageList = DataManage.getMessageData();
		
		gv_emotionList.setAdapter(new EmotionAdapter(ChatActivity.this, emotionList));
		lv_messagesList.setAdapter(new MessageAdapter(ChatActivity.this, messageList));
		
		gv_emotionList.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0,// The AdapterView where the click happened
												View arg1,// The view within the AdapterView that was clicked
												int arg2,// The position of the view in the adapter
												long arg3// The row id of the item that was clicked
			) {
				// 在本例中arg2=arg3
				@SuppressWarnings("unchecked")
				HashMap<String, Object> item = (HashMap<String, Object>) arg0.getItemAtPosition(arg2);
				// 显示所选Item的ItemText
				setTitle((String) item.get("ItemText"));
				selectedTitle = (String) item.get("ItemText");
				DialogTool.showInfo(ChatActivity.this, selectedTitle);
				Log.i("sbEmotionView-click", (String) item.get("ItemText"));
				
				view_emotion.setVisibility(View.GONE);
			}
        });
	
		
	}


	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_a01:// 應用退出
			this.finish();
			// android.os.Process.killProcess(android.os.Process.myPid());
			// System.exit(0);
			break;
		case R.id.menu_a02:// 跳轉到分類列表的頁面
			Intent toAbout = new Intent(this, AboutActivity.class);
			this.startActivity(toAbout);
			break;
		// case R.id.menu_a03:// help 顯示一個dialog
		// this.showDialog(R.id.menu_a02);
		// break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private ArrayList<HashMap<String, Object>> getEmotionData(){
		ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_smile);//添加项目图标
		map.put("ItemText", "smile");////添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_surprise);//添加项目图标
		map.put("ItemText", "surprise");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_happy);//添加项目图标
		map.put("ItemText", "happy");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_smile2);//添加项目图标
		map.put("ItemText", "smile2");///添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_grimace);//添加项目图标
		map.put("ItemText", "grimace");///添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_afraid);//添加项目图标
		map.put("ItemText", "afraid");//添加项目标题
    	lstImageItem.add(map);

    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_monkey);//添加项目图标
		map.put("ItemText", "monkey");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_inebriation);//添加项目图标
		map.put("ItemText", "inebriation");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_glasses);//添加项目图标
		map.put("ItemText", "glasses");///添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_blink);//添加项目图标
		map.put("ItemText", "blink");///添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_hurt);//添加项目图标
		map.put("ItemText", "hurt");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_kiss);//添加项目图标
		map.put("ItemText", "kiss");//添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_weep);//添加项目图标
		map.put("ItemText", "weep");///添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("ItemImage", R.drawable.emotion_laugh);//添加项目图标
		map.put("ItemText", "laugh");///添加项目标题
    	lstImageItem.add(map);
    	
        return lstImageItem;
	}
	
	public static class EmotionAdapter extends BaseAdapter {
	
		private List<HashMap<String, Object>> listData;
		private Context currentContext;
		
		public EmotionAdapter(Context context, List<HashMap<String, Object>> list)
		{
			listData = list;
			currentContext = context;
		}		
		public int getCount() {
			return listData.size();
		}

		public Object getItem(int position) {
			return listData.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
	            convertView = LayoutInflater.from(currentContext).inflate(R.layout.chat_emotion_item, null);
	            
	            holder = new ViewHolder();
	            holder.image = (ImageView) convertView.findViewById(R.id.emotion_item_image);
	            holder.title = (TextView) convertView.findViewById(R.id.emotion_item_title);
	            
	            convertView.setTag(holder);
	        } else {
	            holder = (ViewHolder) convertView.getTag();
	        }	        
			
			HashMap<String, Object> hashMap = listData.get(position);
			int imgId = (Integer)hashMap.get("ItemImage");
			String title  =(String) hashMap.get("ItemText");
			Log.d("holder", (holder == null) ? "holder is null":"hoder is not null");
			holder.image.setBackgroundResource(imgId);
			holder.title.setText(title);
			Log.d("imgid",((Integer)imgId).toString());
			
	        return convertView;
		}
		
		static class ViewHolder {
	        TextView title;
	        ImageView image;
	    }
	}

}