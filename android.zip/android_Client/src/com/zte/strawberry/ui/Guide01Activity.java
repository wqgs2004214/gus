package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class Guide01Activity extends ListActivity {

	private List<Map<String, Object>> mData;
	private String selectedTitle = "add ?";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		mData = getData();
		
		SimpleAdapter adapter = new SimpleAdapter(this, mData, R.layout.guide_index_item,
			new String[] { "title", "info", "img" },
			new int[] { R.id.tv_lv_guideindex_title,R.id.tv_lv_guideindex_info, R.id.iv_lv_guideindex_icon });
		
		setListAdapter(adapter);
	}

	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("title", "Add chat account");
		map.put("info", "Add your MSN or Yahoo account here.");
		map.put("img", R.drawable.index_icon01);
		list.add(map);

		map = new HashMap<String, Object>();
		map.put("title", "Add email account");
		map.put("info", "Add your email account.");
		map.put("img", R.drawable.index_icon02);
		list.add(map);

		return list;

	}
	
	// ListView 中某项被选中后的逻辑
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		Log.v("GuideListView-click", (String) mData.get(position).get("title"));
		selectedTitle = (String) mData.get(position).get("title");
		showInfo();
	}

	
	/**
	 * listview中点击按键弹出对话框
	 */
	public void showInfo() {
		new AlertDialog.Builder(this).setTitle("Add account guide")
				.setMessage(selectedTitle)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					}
				}).show();
		
		Intent intent = new Intent();
		intent.setClass(Guide01Activity.this, AddMailChoose.class);
		startActivity(intent);
	}


}
