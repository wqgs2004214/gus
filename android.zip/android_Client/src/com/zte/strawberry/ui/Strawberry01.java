package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.SimpleAdapter;

public class Strawberry01 extends Activity {

	private String selectedTitle = "select ?";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.strawberry01);
		GridView gridview = (GridView) findViewById(R.id.gv_strawberry);

		// 生成动态数组，并且转入数据
		ArrayList<HashMap<String, Object>> lstImageItem = getData();
		// 生成适配器的ImageItem <====> 动态数组的元素，两者一一对应
		SimpleAdapter saImageItems = new SimpleAdapter(this, // 没什么解释
				lstImageItem,// 数据来源
				R.layout.strawberry_item,// strawberry_item的XML实现

				// 动态数组与ImageItem对应的子项
				new String[] { "ItemImage", "ItemText" },

				// ImageItem的XML文件里面的一个ImageView,两个TextView ID
				new int[] { R.id.strawberry_item_image,
						R.id.strawberry_item_title });
		// 添加并且显示
		gridview.setAdapter(saImageItems);
		// 添加消息处理
		gridview.setOnItemClickListener(new ItemClickListener());
	}

	// 当AdapterView被单击(触摸屏或者键盘)，则返回的Item单击事件
	class ItemClickListener implements OnItemClickListener {
		@SuppressWarnings("unchecked")
		public void onItemClick(AdapterView<?> arg0,// The AdapterView where the
													// click happened
				View arg1,// The view within the AdapterView that was clicked
				int arg2,// The position of the view in the adapter
				long arg3// The row id of the item that was clicked
		) {
			// 在本例中arg2=arg3
			HashMap<String, Object> item = (HashMap<String, Object>) arg0.getItemAtPosition(arg2);
			// 显示所选Item的ItemText
			setTitle((String) item.get("ItemText"));
			selectedTitle = (String) item.get("ItemText");
			showInfo();
			Log.i("sbGridView-click", (String) item.get("ItemText"));

		}
	}


	// gridview中点击按键弹出对话框
	public void showInfo() {
		new AlertDialog.Builder(Strawberry01.this)
				.setTitle(selectedTitle)
				.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
							}
						})
				.setItems(R.array.imp_contact_from_items,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								/* User clicked so do some stuff */
								String[] items = getResources()
										.getStringArray(
												R.array.imp_contact_from_items);
								new AlertDialog.Builder(Strawberry01.this)
										.setMessage(
												"You selected: " + which
														+ " , "
														+ items[which])
										.show();
							}
						}).show();

		// Intent intent = new Intent();
		// intent.setClass(Strawberry01.this, AboutActivity.class);
		// startActivity(intent);

	}

	private ArrayList<HashMap<String, Object>> getData() {
		ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("ItemImage", R.drawable.contact);// 添加项目图标
		map.put("ItemText", "Contact");// //添加项目标题
		lstImageItem.add(map);

		map = new HashMap<String, Object>();
		map.put("ItemImage", R.drawable.chat);// 添加项目图标
		map.put("ItemText", "Chat");// 添加项目标题
		lstImageItem.add(map);

		map = new HashMap<String, Object>();
		map.put("ItemImage", R.drawable.community);// 添加项目图标
		map.put("ItemText", "Community");// 添加项目标题
		lstImageItem.add(map);

		map = new HashMap<String, Object>();
		map.put("ItemImage", R.drawable.email);// 添加项目图标
		map.put("ItemText", "Email");// /添加项目标题
		lstImageItem.add(map);

		map = new HashMap<String, Object>();
		map.put("ItemImage", R.drawable.help);// 添加项目图标
		map.put("ItemText", "Help");// /添加项目标题
		lstImageItem.add(map);

		map = new HashMap<String, Object>();
		map.put("ItemImage", R.drawable.setting);// 添加项目图标
		map.put("ItemText", "Setting");// 添加项目标题
		lstImageItem.add(map);

		return lstImageItem;
	}

}
