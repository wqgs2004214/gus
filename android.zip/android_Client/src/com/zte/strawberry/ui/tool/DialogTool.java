package com.zte.strawberry.ui.tool;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

/**
 * @author 6235000036
 */
public class DialogTool { //extends Activity

	/**
	 * @param context
	 *            上下文環境
	 * @param message
	 *            信息內容
	 */
	public static void showInfo(Context context, String message) {
		new AlertDialog.Builder(context).setTitle("Show message")
				.setMessage(message)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					}
				}).show();
	}

	/**
	 * @param context
	 *            上下文環境
	 * @param title
	 *            標題
	 * @param msg
	 *            信息內容
	 * @param ancelable
	 *            取消按鈕
	 * @param runtime
	 *            運行時間
	 */
	public static void showProgressDialog(Context context, String title,
			String msg, boolean cancelable, long runtime, int iconId) {
		final ProgressDialog mypDialog = new ProgressDialog(context);
		mypDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		// 设置ProgressDialog 标题
		mypDialog.setTitle(title);
		// 设置ProgressDialog 提示信息
		mypDialog.setMessage(msg);
		// 设置ProgressDialog 标题图标
		mypDialog.setIcon(iconId);
		// 设置ProgressDialog 的进度条是否不明确
		mypDialog.setIndeterminate(false);
		// 设置ProgressDialog 是否可以按退回按键取消
		mypDialog.setCancelable(cancelable);
		// 让ProgressDialog 显示
		mypDialog.show();
		new Timer().schedule(new TimerTask() {
			@Override
			public void run() {
				mypDialog.dismiss();
			}
		}, runtime);
	}


	public static void showStepProgressDialog(Context context,
			final List<Step> steps) {
		Step firststep = steps.get(0);
		final ProgressDialog mypDialog = new ProgressDialog(context);
		mypDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); //
		// 设置ProgressDialog 标题
		mypDialog.setTitle(firststep.getTitle()); // 设置ProgressDialog 提示信息
		mypDialog.setMessage(firststep.getMsg()); // 设置ProgressDialog 标题图标
		mypDialog.setIcon(firststep.getIconId()); // 设置ProgressDialog 的进度条是否不明确
		mypDialog.setIndeterminate(false); // 设置ProgressDialog 是否可以按退回按键取消
		mypDialog.setCancelable(false); // 让ProgressDialog 显示
		mypDialog.show();
		final Activity activity = (Activity) context;
		DialogTool dt = new DialogTool();
		CustomTimer ct = dt.new CustomTimer();
		for (int i = 0; i < steps.size() - 1; i++) {
			final int index = i + 1;
			CustomTimer.Task tsk = ct.new Task() {
				@Override
				public long getDelay() {
					return steps.get(index).getTime();
				}

				@Override
				public void run() {
					if (steps.get(index).closeDialog) {
						mypDialog.dismiss();
					} else {
						activity.runOnUiThread(new Runnable() {
							public void run() {
								mypDialog.setMessage(steps.get(index).getMsg());
								mypDialog.setTitle(steps.get(index).getTitle());
							}
						});
					}
				}

			};
			ct.addTask(tsk);
		}
		ct.start();
	}

	/**
	 * @depreciated
	 * 請用showStepProgressDialog 可以進行多步的dialog顯示
	 * @param context
	 * @param title
	 * @param msg
	 * @param cancelable
	 * @param runtime
	 * @param iconId
	 * @param title2
	 * @param msg2
	 * @param closetime
	 */
	public static void showProgressDialog2(Context context, String title,
			String msg, boolean cancelable, final long runtime, int iconId,
			final String title2, final String msg2, final long closetime) {
		final ProgressDialog mypDialog = new ProgressDialog(context);
		mypDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); //
		// 设置ProgressDialog 标题
		mypDialog.setTitle(title); // 设置ProgressDialog 提示信息
		mypDialog.setMessage(msg); // 设置ProgressDialog 标题图标
		mypDialog.setIcon(iconId); // 设置ProgressDialog 的进度条是否不明确
		mypDialog.setIndeterminate(false); // 设置ProgressDialog 是否可以按退回按键取消
		mypDialog.setCancelable(cancelable); // 让ProgressDialog 显示
		mypDialog.show();
		// final Handler currentHandler = new
		// EHandler(Looper.getMainLooper(),mypDialog);
		final Activity activity = (Activity) context;

		// new Timer().schedule(new TimerTask() {
		// @Override
		// public void run() {
		// // Message msg= currentHandler.obtainMessage(1,1,1,msg2);
		// // currentHandler.sendMessage(msg);
		// // 試試用runOnUiThread方法
		// activity.runOnUiThread(new Runnable() {// 對UI的操作放在uiThread里面
		// public void run() {
		// mypDialog.setMessage(msg2);
		// mypDialog.setTitle(title2);
		// };
		// });
		// new Timer().schedule(new TimerTask() {
		// @Override
		// public void run() {
		// mypDialog.dismiss();
		// }
		// }, closetime);
		// }
		// }, runtime);
		// test...
		DialogTool dt = new DialogTool();
		CustomTimer ct = dt.new CustomTimer();
		dt.new CustomTimer().addTask(ct.new Task() {
			@Override
			public long getDelay() {
				return runtime;
			}

			@Override
			public void run() {
				activity.runOnUiThread(new Runnable() {
					public void run() {
						mypDialog.setMessage(msg2);
						mypDialog.setTitle(title2);
					}

				});

			}
		}).addTask(ct.new Task() {
			@Override
			public long getDelay() {
				return runtime;
			}

			@Override
			public void run() {
				activity.runOnUiThread(new Runnable() {
					public void run() {
						mypDialog.setMessage("third message");
						mypDialog.setTitle("third title");
					}

				});

			}
		}).addTask(ct.new Task() {

			@Override
			public long getDelay() {
				return closetime;
			}

			@Override
			public void run() {
				mypDialog.dismiss();
			}

		}).start();

	}

	static class EHandler extends Handler {
		private ProgressDialog progressDialog;

		public EHandler(Looper looper) {
			super(looper);
		}

		public EHandler(Looper looper, ProgressDialog dialog) {
			super(looper);
			progressDialog = dialog;
		}

		@Override
		public void handleMessage(Message msg) {
			progressDialog.setMessage(msg.obj.toString());
		}
	}

	public class CustomTimer extends Timer {
		List<Task> taskList = new ArrayList<Task>();

		public CustomTimer addTask(Task task) {
			int index = taskList.size();
			taskList.add(task);
			if (index > 0) {
				taskList.get(index - 1).setNextTask(task);
			}
			return this;
		}

		public void start() {
			if (taskList.size() > 0) {
				sched(this, taskList.get(0));
			}
		}

		private CustomTimer sched(final CustomTimer currentCustomTimer,
				final Task currenttask) {
			final CustomTimer next = new DialogTool().new CustomTimer();
			currentCustomTimer.schedule(new TimerTask() {
				@Override
				public void run() {
					currenttask.run();
					if (currenttask.getNextTask() != null) {
						sched(next, currenttask.getNextTask());
					}
				}
			}, currenttask.getDelay());
			return currentCustomTimer;
		}

		public abstract class Task {
			private Task nextTask;

			public abstract void run();

			public abstract long getDelay();

			public Task getNextTask() {
				return nextTask;
			};

			public void setNextTask(Task next) {
				this.nextTask = next;
			}
		}
	}

	public class Step {
		boolean closeDialog;
		String title, msg;
		int iconId;// 只需要first step 設置iconId
		long time;

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

		public long getTime() {
			return time;
		}

		public void setTime(long time) {
			this.time = time;
		}

		public Step(String title, String msg,long time,int iconId,Boolean closeDialog) {
			this.title = title;
			this.msg = msg;
			this.time = time;
			this.iconId = iconId;
			this.closeDialog = (null == closeDialog)?false:closeDialog;
		}

		public boolean isCloseDialog() {
			return closeDialog;
		}

		public void setCloseDialog(boolean closeDialog) {
			this.closeDialog = closeDialog;
		}

		public int getIconId() {
			return iconId;
		}

		public void setIconId(int iconId) {
			this.iconId = iconId;
		}

	}
}
