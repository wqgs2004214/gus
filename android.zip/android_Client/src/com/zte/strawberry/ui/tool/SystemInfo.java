package com.zte.strawberry.ui.tool;

import java.lang.reflect.Field;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;

/**
 * get System build information, useful for debug.
 *
 * @author bangbang.S
 */
public final class SystemInfo {
	@SuppressWarnings("unchecked")
	public static String toStr() {
		Class<Build> c;
		try{
			String ret = "";
			// nested class '$'
			c = (Class<Build>) Class.forName("android.os.Build$VERSION");
			Field[] fields = c.getFields();
			
			for (Field f : fields) {
				ret += "[" + f.getName() + ':' + f.get(c).toString() + ']';
			}
//			c = (Class<Build>) Class.forName("android.os.Build");
//			fields = c.getFields();
//			
//			for (Field f : fields) {
//				ret += "[" + f.getName() + ':' + f.get(c).toString() + ']';
//			}
			
			return ret;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} finally {

		}
		

		return "";
	}
	public static String getVersion(Context con){
		String body = "";
       	PackageManager pm = con.getPackageManager();
    	PackageInfo info = null;
    	try {
			info = pm.getPackageInfo(con.getPackageName(), 0);
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			int code = info.versionCode;
			String name = info.versionName;
			
			body += "versionCode: " + code + "\n";
			body += "versionName: " + name;
		}
		
		return body;
	}
}
