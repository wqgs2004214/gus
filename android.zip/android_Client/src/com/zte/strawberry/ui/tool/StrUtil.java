package com.zte.strawberry.ui.tool;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import android.util.Log;


public final class StrUtil {

    private static DocumentBuilder db = null;
    private static final DateFormat siptimeformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    public static String toXml(String s) {
        return s.replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;").replace("&", "&amp;");
    }

    public static String xmlToString(String s) {
        return s.replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
    }

    public static int parseInt(String s, int def) {
        try {
            int i = Integer.parseInt(s);
            return i;
        } catch (Exception e) {
            return def;
        }
    }
    
    public static String getDate() {
        return String.format("%tR", Calendar.getInstance());
    }
    
    /* 
     * get ID (sip:xxx or tel:xxx) from 
     * sip:xxxx@fetiom.com.cn.@$#^#$&% or 
     * tel:xxxxx@fetion.com.cn&$$$%^#@!
     * 
     * bangbang.song@gmail.com
     */
    public static String getPeopleId(String str){
    	String splits[] = Pattern.compile("@", Pattern.LITERAL).split(str);
    	return splits[0];
    }

    public static Document parseXmlDocument(String xml) {
        if (db == null) {
            try {
                db  = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
                return null;
            }
        }
        ByteArrayInputStream bis = null;
        try {
            bis = new ByteArrayInputStream(xml.getBytes());
            Document dom = db.parse(bis);
            dom.getDocumentElement().normalize();
            return dom;
        } catch (SAXException e) {
            Log.e("ShaoLin", xml);
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                }
            }
        }
    }

    public static String realTime(String time) {
        Calendar cal =Calendar.getInstance(); 
        try {
            cal.setTime(siptimeformat.parse(time));
            cal.add(Calendar.HOUR_OF_DAY, 8);
        } catch (Exception e) {
            return "Time error";
        }
        return String.format("%tF %tR", cal, cal);
    }
    
    public static String getLength(StringBuilder body) {
        try {
            return String.valueOf(body.toString().getBytes("UTF-8").length);
        } catch (UnsupportedEncodingException e) {
            return String.valueOf(body.toString().getBytes().length);
        }
    }

    public static String getLength(String body) {
        try {
            return String.valueOf(body.getBytes("UTF-8").length);
        } catch (UnsupportedEncodingException e) {
            return String.valueOf(body.getBytes().length);
        }
    }

    public static long parseLong(String s, long def) {
        try {
            long i = Long.parseLong(s);
            return i;
        } catch (Exception e) {
            return def;
        }
    }

}
