package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.zte.strawberry.ui.tool.DialogTool;

public class Mailboxes extends Activity {

	Button button_home;
	Button button_refresh;
	Button button_compose;
	Button button_more;
	
	ListView lv_inbox;
	ListView lv_account;
	
	public static Context mailboxContext;
	private ArrayList<HashMap<String, Object>> inboxList;
	private ArrayList<HashMap<String, Object>> accountList;
//	private String selectedTitle = "add ?";
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.main_menu,
			R.menu.save_menu };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mailboxes);
		    
		button_home = (Button) findViewById(R.id.btn_mailbox_home);
		button_refresh = (Button) findViewById(R.id.btn_mailbox_refresh);	
		button_compose = (Button) findViewById(R.id.btn_mailbox_compose);
		button_more = (Button) findViewById(R.id.btn_mailbox_home);
		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Mailboxes.this.openOptionsMenu();
			}
		});
		
		button_home.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent(Mailboxes.this, Strawberry.class);
        		startActivity(intent);
			}
		});
		
		button_refresh.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent(Mailboxes.this, MailList.class);
        		startActivity(intent);
			}
		});
		
		mailboxContext=this;
		lv_inbox= (ListView)findViewById(R.id.lv_mailbox_inbox);
		lv_account = (ListView)findViewById(R.id.lv_mailbox_account);
		inboxList = getInboxData();
		accountList = getAccountData();
		
		SimpleAdapter inboxAdapter = new SimpleAdapter(this, inboxList, R.layout.mailhead_item,
				new String[] { "MailHead" , "MailName" , "MailSize"},//
				new int[] { R.id.iv_mailhead_icon ,R.id.tv_mailhead_name ,R.id.tv_mailhead_size});//		

		SimpleAdapter acconutAdapter = new SimpleAdapter(this, accountList, R.layout.mailhead_item,
				new String[] { "MailHead" , "MailName" , "MailSize"},//
				new int[] { R.id.iv_mailhead_icon ,R.id.tv_mailhead_name ,R.id.tv_mailhead_size});//
		
		lv_inbox.setAdapter(inboxAdapter);
		lv_account.setAdapter(acconutAdapter);
		
		lv_inbox.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0,View arg1,int arg2,long arg3) {
//				@SuppressWarnings("unchecked")
//				HashMap<String, Object> item = (HashMap<String, Object>) arg0.getItemAtPosition(arg2);
				// 显示所选Item的ItemText
				DialogTool.showInfo(Mailboxes.this, "Inbox");
			}
        });
		
		lv_account.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0,View arg1,int arg2,long arg3) {
//				@SuppressWarnings("unchecked")
//				HashMap<String, Object> item = (HashMap<String, Object>) arg0.getItemAtPosition(arg2);
				// 显示所选Item的ItemText
				DialogTool.showInfo(Mailboxes.this, "Account");
			}
        });
		
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.main_menu, true);
			menu.setGroupVisible(R.menu.save_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_a01:// 應用退出
			this.finish();
			// android.os.Process.killProcess(android.os.Process.myPid());
			// System.exit(0);
			break;
		case R.id.menu_a02:// 跳轉到分類列表的頁面
			Intent toAbout = new Intent(this, AboutActivity.class);
			this.startActivity(toAbout);
			break;
		// case R.id.menu_a03:// help 顯示一個dialog
		// this.showDialog(R.id.menu_a02);
		// break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private ArrayList<HashMap<String, Object>> getInboxData(){
		ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("MailHead", R.drawable.mail_normal);//添加项目图标
		map.put("MailName", "All Inboxes");////添加项目标题
		map.put("MailSize", "(0/25)");////添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailHead", R.drawable.mail_normal);//添加项目图标
		map.put("MailName", "Gmail");//添加项目标题
		map.put("MailSize", "(0/15)");////添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailHead", R.drawable.mail_normal);//添加项目图标
		map.put("MailName", "Yahoo");//添加项目标题
		map.put("MailSize", "(0/10)");////添加项目标题
    	lstImageItem.add(map);
    	
        return lstImageItem;
	}
	
	private ArrayList<HashMap<String, Object>> getAccountData(){
		ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();
        
    	HashMap<String, Object> map = new HashMap<String, Object>();
    	map.put("MailHead", R.drawable.mail_gmail);//添加项目图标
		map.put("MailName", "Gmail");////添加项目标题
		map.put("MailSize", "(0/15)");////添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailHead", R.drawable.mail_yahoo);//添加项目图标
		map.put("MailName", "Yahoo");//添加项目标题
		map.put("MailSize", "(0/10)");////添加项目标题
    	lstImageItem.add(map);
    	
    	map = new HashMap<String, Object>();
    	map.put("MailHead", null);//添加项目图标
		map.put("MailName", "Add account…");//添加项目标题
		map.put("MailSize", null);////添加项目标题
    	lstImageItem.add(map);
    	
        return lstImageItem;
	}

}