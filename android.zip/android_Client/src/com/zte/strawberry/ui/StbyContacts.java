package com.zte.strawberry.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Contacts.People;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.zte.strawberry.dataset.DataManage;
import com.zte.strawberry.ui.tool.DialogTool;

@SuppressWarnings("deprecation")
public class StbyContacts extends Activity {


	Button button_more;
	Button button_home;
	Button button_refresh;
//	Button button_preprocess;
	ListView lv_contacts;
	
	private String selectedTitle = "add ?";
	public static Context contactsContext;
	private ArrayList<HashMap<String, Object>> contactList;
	
	protected int myMenuSettingTag = 1;
	protected Menu myMenu;
	private static final int myMenuResources[] = { R.menu.contact_menu,
		R.menu.select_menu,R.menu.main_menu,R.menu.save_menu };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.stby_contacts);
		
		button_more = (Button) findViewById(R.id.btn_contacts_more);
		button_home = (Button) findViewById(R.id.btn_contacts_home);
		button_refresh = (Button) findViewById(R.id.btn_contacts_refresh);
//		button_preprocess = (Button) findViewById(R.id.btn_contact_preprocess );
		
		button_more.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				StbyContacts.this.openOptionsMenu();
			}
		});
		
		button_refresh.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent(StbyContacts.this, ContactPreprocess.class);
				startActivity(intent);
			}
		});
		
		button_home.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				Intent intent = new Intent(StbyContacts.this, Strawberry.class);
				startActivity(intent);
			}
		});
		
//		button_preprocess.setOnClickListener(new OnClickListener() {
//			public void onClick(View view) {
//				Intent intent = new Intent();
//				intent.setClass(Contacts.this, ContactPreprocess.class);
//				startActivity(intent);
//			}
//		});
		
		
		lv_contacts = (ListView)this.findViewById(R.id.lv_contacts_list);
		
//		contactList = getData();
//		SimpleAdapter adapter = new SimpleAdapter(this, contactList, R.layout.sim_contact_item,
//				new String[] { "icon", "line" },
//				new int[] { R.id.iv_lv_mail_icon,R.id.tv_mailchoose_line });		
//		lv_sim_contact.setAdapter(adapter);
		
//		Cursor cursor = getContentResolver().query(People.CONTENT_URI, null, null, null, null);
//		startManagingCursor(cursor);
//		
//        ListAdapter listAdapter = new SimpleCursorAdapter(StbyContacts.this, R.layout.contact_item,
//        		                cursor,
//        		                new String[]{People.NAME},
//        		                new int[]{R.id.tv_contact_name});
//
//        lv_contacts.setAdapter(listAdapter);
        
        contactList = DataManage.getContacts();
        ListAdapter listAdapter = new SimpleAdapter(this, contactList, R.layout.contact_item,
				new String[] { "Name" },//
				new int[] { R.id.tv_contact_name  });//		
        lv_contacts.setAdapter(listAdapter);

        
		lv_contacts.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//				Log.v("MailListView-click", (String) contactsList.get(position).get("name"));
//				selectedTitle = (String) contactsList.get(position).get("name");
//				showInfo();
				
				DialogTool.showInfo(StbyContacts.this, "click contact");
				
				Intent intent = new Intent(StbyContacts.this, ContactPreprocess.class);
				startActivity(intent);
			}
        });
		
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		boolean result = super.onPrepareOptionsMenu(menu);
		switch (myMenuSettingTag) {
		case 1:
			menu.setGroupVisible(R.menu.contact_menu, true);
			menu.setGroupVisible(R.menu.main_menu, false);
			break;
		default:
			menu.setGroupVisible(R.menu.contact_menu, true);
			menu.setGroupVisible(R.menu.main_menu, false);
			break;
		}
		return result;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Hold on to this
		myMenu = menu;
		myMenu.clear();// 清空MENU菜单
		// Inflate the currently selected menu XML resource.
		MenuInflater inflater = getMenuInflater();
		// 从TabActivity这里获取一个MENU过滤器
		switch (myMenuSettingTag) {
		case 1:
			inflater.inflate(myMenuResources[0], menu);
			// 动态加入数组中对应的XML MENU菜单
			break;
		case 2:
			inflater.inflate(myMenuResources[1], menu);
			break;
		default:
			inflater.inflate(myMenuResources[0], menu);
			break;
		}
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {

		case R.id.menu_contact_add:
			DialogTool.showInfo(this, "menu_contact_add");
			break;
		case R.id.menu_contact_view:
			DialogTool.showInfo(this, "menu_contact_view");
			break;
		case R.id.menu_contact_import:
			DialogTool.showInfo(this, "menu_contact_import");
			break;
		case R.id.menu_contact_delete:
			DialogTool.showInfo(this, "menu_contact_delete");
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		this.findViewById(keyCode).setBackgroundColor(R.color.LOWGRAY);
//		return super.onKeyDown(keyCode, event);
//	}
	
	@SuppressWarnings("unused")
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("icon", R.drawable.gmail);
//		map.put("line", R.color.GRAY);
//		map.put("title", "gmail");
		list.add(map);
		map = new HashMap<String, Object>();
//		map.put("icon", R.drawable.other);
//		map.put("line", R.color.GRAY);
//		map.put("title", "other");
		list.add(map);
		
		Cursor cursor = getContentResolver().query(People.CONTENT_URI, null, null, null, null);
		startManagingCursor(cursor);

		return list;
	}

//	listview中点击按键弹出对话框
	public void showInfo() {
		new AlertDialog.Builder(this).setTitle("Select contacts")
				.setMessage(selectedTitle)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					}
				}).show();
		
		//跳转到添加邮件界面
		Intent intent = new Intent();
		intent.setClass(StbyContacts.this, AddMailDetail01.class);
		startActivity(intent);
	}

	// 按下任意键跳转到联系人预处理界面
//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		Intent intent = new Intent(StByContacts.this, ContactPreprocess.class);
//		startActivity(intent);
//		return super.onKeyDown(keyCode, event);
//	}
	
}
