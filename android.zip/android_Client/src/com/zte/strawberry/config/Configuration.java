package com.zte.strawberry.config;

public class Configuration {
	public static final String C = "contact;chat;community;email;files;";
	
}
