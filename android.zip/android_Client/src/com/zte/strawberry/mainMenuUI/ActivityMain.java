package com.zte.strawberry.mainMenuUI;

import java.util.Vector;

import com.zte.strawberry.component.Component;
import com.zte.strawberry.ui.Strawberry;

public class ActivityMain {
	public Vector<Component> components;
	public ActivityMain(Strawberry strawberry) {
		components = new Vector<Component>();
	}
	
	/**
	 * 移除所有已加载的组件
	 */
	public void removeAllComponents() {
        synchronized (components) {
            components.removeAllElements();
        }
    }
	
	/**
	 * 添加不存在的组件 
	 * @param component 组件
	 */
	public void addComponentIfNotExists(Component component) {
        synchronized (components) {
            if (components.contains(component)) {
                return;
            }
            components.addElement(component);
        }
    }
}
