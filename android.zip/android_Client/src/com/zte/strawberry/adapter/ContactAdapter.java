package com.zte.strawberry.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.zte.strawberry.ui.R;

/**
 * @author 6235000036
 * @version Create：2010-12-10 上午10:56:51
 */

public class ContactAdapter extends BaseAdapter {
        
    private Context mContext;
 	
    public ContactAdapter(Context c) {
    	mContext = c;
   	}

        public int getCount() {
            return tempContacts.length;
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv = new TextView(mContext);

            tv.setText(tempContacts[position]);
            tv.setTextSize(20);
            tv.setTextColor(android.graphics.Color.BLACK);
            tv.setPadding(5, 5, 5, 5);
            tv.setBackgroundResource(R.drawable.chat_head_click);
            
            return tv;
        }

        private String[] tempContacts = {
        		"小李",
        		"小丽",
        		"小张"
        };
}

