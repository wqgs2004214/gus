package com.zte.strawberry.adapter;

/**
 * @author 6235000036
 * @version Create：2010-12-8 下午01:53:39
 */

import java.util.HashMap;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.zte.strawberry.ui.R;


public class MessageAdapter  extends BaseAdapter {
	
	private List<HashMap<String, Object>> mData=null;
	private Context currentContext;
	@SuppressWarnings("unused")
	private LayoutInflater mInflater;
	
	public Context getCurrentContext() {
		return currentContext;
	}

	public void setCurrentContext(Context currentContext) {
		this.currentContext = currentContext;
	}
	
	
	public List<HashMap<String, Object>> getMData() {
		return mData;
	}

	public void setMData(List<HashMap<String, Object>> data) {
		mData = data;
	}

	public MessageAdapter(Context context) {
		this.mInflater = LayoutInflater.from(context);
	}

	public int getCount() {
		return mData==null?0:mData.size();
	}

	public Object getItem(int position) {
		return null;
	}

	public long getItemId(int position) {
		return 0;
	}
	
	public MessageAdapter(Context context, List<HashMap<String, Object>> list)
	{
		mData = list;
		currentContext = context;
	}		

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(currentContext).inflate(R.layout.chat_message_item, null);
			
			holder.chat_massage = (TextView) convertView.findViewById(R.id.tv_message);
			holder.massage_time = (TextView) convertView.findViewById(R.id.tv_message_time);
			
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		holder.chat_massage.setText((String)mData.get(position).get("ChatMassage"));
		holder.massage_time.setText((CharSequence) mData.get(position).get("MassageTime"));
		
		return convertView;
	}
	/**
	 * listview's holder
	 */
	public final class ViewHolder {
		public TextView chat_massage;
		public TextView massage_time;
	}
}
