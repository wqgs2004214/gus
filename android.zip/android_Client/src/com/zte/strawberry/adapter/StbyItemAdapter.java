package com.zte.strawberry.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.zte.strawberry.ui.R;
import com.zte.strawberry.entity.StbyItem;

public class StbyItemAdapter extends BaseAdapter {

	private class ItemHolder {
		@SuppressWarnings("unused")
		ImageView itemImage;
		TextView itemName;
		
	}
	
	private Context context;

	private List<StbyItem> list;
	private LayoutInflater mInflater;

	public StbyItemAdapter(Context c) {
		super();
		this.context = c;
	}

	public void setList(List<StbyItem> list) {
		this.list = list;
		mInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

	}

	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}


	public Object getItem(int index) {

		return list.get(index);
	}

	public long getItemId(int index) {
		return index;
	}

	public View getView(int index, View convertView, ViewGroup parent) {
		ItemHolder holder;
		if (convertView == null) {   
			convertView = mInflater.inflate(R.layout.strawberry_item, null);   
			holder = new ItemHolder();
			holder.itemImage = ((ImageView)convertView.findViewById(R.id.strawberry_item_image));
			holder.itemName = (TextView)convertView.findViewById(R.id.strawberry_item_title);
			convertView.setTag(holder);  

		}else{
			 holder = (ItemHolder) convertView.getTag();   
		}
		StbyItem info = list.get(index);
		if (info != null) {   
			holder.itemName.setText(info.getName());
		}
		return convertView;
	}
	
}
