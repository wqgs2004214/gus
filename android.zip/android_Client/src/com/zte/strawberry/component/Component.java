package com.zte.strawberry.component;

public interface Component
{
	
}
